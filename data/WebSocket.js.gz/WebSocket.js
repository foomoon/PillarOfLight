var connection;

function wsconnect() {
    connection = new WebSocket('ws://'+location.hostname+':81/', ['arduino']);

    connection.onopen = function () {
        //connection.send();
        sendDataAsJSON();
    };
    connection.onerror = function (error) {
        console.log('WebSocket Error ', error);
    };
    connection.onmessage = function (e) {  
        console.log('Server: ', e.data);
    };
    connection.onclose = function(){
        console.log('WebSocket connection closed');
        console.log ('Attempting to reconnect...');
        setTimeout(function() {
            wsconnect();
        }, 1000);
    };

}


wsconnect();

var data = {
    deviceID: 1,
    color: "#0000ff",
    hsv: {
        h: 0,
        s: 50,
        v: 100
    },
    brightness: 32,
    spark: 50,
    cooling: 50,
    text: " ",
};

function $(id) {
    return document.getElementById(id);
}

// function sendRGB() {
//     var r = $('r').value**2/255;
//     var g = $('g').value**2/255;
//     var b = $('b').value**2/255;
    
//     var rgb = r << 16 | g << 8 | b;
//     var rgbstr = '#'+ rgb.toString(16);  
//     data.color = rgbstr;  
//     console.log('RGB: ' + rgbstr); 
//     connection.send(rgbstr);
// }

function sendBrightness() {
    data.brightness = $('brightness').value;
    sendDataAsJSON();
}

function sendSpeed() {
    data.speed = Number($('speed').max) - Number($('speed').value) + Number($('speed').min);
    sendDataAsJSON();
}

function sendSpark() {
    data.spark = $('spark').value;
    sendDataAsJSON();
}

function sendCool() {
    data.cooling = $('cooling').value;
    sendDataAsJSON();
}

function sendText() {
    var txt = $('message').value;
    if (txt.length==0) {
        txt = "...";
    }
    data.text = txt;
    sendDataAsJSON();
}

function sendDataAsJSON() {
    data.timeStamp = ' ' + new Date();
    console.log(data);
    connection.send(JSON.stringify(data));
}
